var networks = {"ExecEdges.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "ExecEdges.csv",
    "name" : "ExecEdges.csv",
    "SUID" : 62,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "112",
        "shared_name" : "18",
        "Type" : "Person",
        "Position_" : "President",
        "Connection_" : 3,
        "name" : "18",
        "SUID" : 112,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -639.2737667323545,
        "y" : -1114.8209228515625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "shared_name" : "Jewish Board of Guardians",
        "Type" : "",
        "Position_" : "",
        "name" : "Jewish Board of Guardians",
        "SUID" : 111,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1885.6485595703125,
        "y" : 22.569509506225586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "shared_name" : "Jewish Lads' Brigade",
        "Type" : "",
        "Position_" : "",
        "name" : "Jewish Lads' Brigade",
        "SUID" : 110,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1599.9267578125,
        "y" : 882.3568115234375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "shared_name" : "Royal Commission on Alien Immigration ",
        "Type" : "",
        "Position_" : "",
        "name" : "Royal Commission on Alien Immigration ",
        "SUID" : 109,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : -2021.7440480640978,
        "y" : -425.95123291015625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "23",
        "Type" : "Person",
        "Position_" : "Chairmen of Entertainment",
        "Connection_" : 4,
        "name" : "23",
        "SUID" : 108,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -391.5924072265625,
        "y" : 609.3737270409563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "Jewish Religious Education Board ",
        "Type" : "",
        "Position_" : "",
        "name" : "Jewish Religious Education Board ",
        "SUID" : 107,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1813.89794921875,
        "y" : 253.8472900390625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "shared_name" : "Board of Deputies of British Jews",
        "Type" : "",
        "Position_" : "",
        "name" : "Board of Deputies of British Jews",
        "SUID" : 106,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1868.3394775390625,
        "y" : 78.73854064941406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "Maccabæns",
        "Type" : "",
        "Position_" : "",
        "name" : "Maccabæns",
        "SUID" : 105,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1685.90625,
        "y" : 691.7782007864126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "shared_name" : "Jewish Working Men's Club ",
        "Type" : "",
        "Position_" : "",
        "name" : "Jewish Working Men's Club ",
        "SUID" : 104,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1617.2813720703125,
        "y" : 819.89794921875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "29",
        "Type" : "Person",
        "Position_" : "Owner",
        "Connection_" : 4,
        "name" : "29",
        "SUID" : 103,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -601.1903076171875,
        "y" : 475.24686546869066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "Society of Jewish Statistics ",
        "Type" : "",
        "Position_" : "",
        "name" : "Society of Jewish Statistics ",
        "SUID" : 102,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1785.69921875,
        "y" : 319.9053955078125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "shared_name" : "The Jewish Chronicle ",
        "Type" : "",
        "Position_" : "",
        "name" : "The Jewish Chronicle ",
        "SUID" : 101,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1757.8731689453125,
        "y" : 441.1225891113281
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "33",
        "Type" : "Person",
        "Position_" : "Treasurer",
        "Connection_" : 3,
        "name" : "33",
        "SUID" : 100,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -492.9552001953125,
        "y" : -588.5513305664062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "42",
        "Type" : "Person",
        "Position_" : "Honorary President",
        "Connection_" : 5,
        "name" : "42",
        "SUID" : 99,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 293.64178466796875,
        "y" : 876.4486694335938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "shared_name" : "Poor Jews' Temporary Shelter",
        "Type" : "",
        "Position_" : "",
        "name" : "Poor Jews' Temporary Shelter",
        "SUID" : 98,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1777.700927734375,
        "y" : 376.0272521972656
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "shared_name" : "44",
        "Type" : "Person",
        "Position_" : "Treasurer",
        "Connection_" : 3,
        "name" : "44",
        "SUID" : 97,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -433.5040588378906,
        "y" : -480.9635009765625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "shared_name" : "47",
        "Type" : "Person",
        "Position_" : "",
        "Connection_" : 3,
        "name" : "47",
        "SUID" : 96,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -617.9314944981143,
        "y" : -1047.949462890625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "shared_name" : "55",
        "Type" : "Person",
        "Position_" : "Honoary Secretary",
        "Connection_" : 3,
        "name" : "55",
        "SUID" : 95,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -312.3344639494011,
        "y" : -227.8468017578125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "Anglo-Jewish Association",
        "Type" : "",
        "Position_" : "",
        "name" : "Anglo-Jewish Association",
        "SUID" : 94,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1858.7669677734375,
        "y" : 146.43821716308594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "shared_name" : "69",
        "Type" : "Person",
        "Position_" : "President",
        "Connection_" : 4,
        "name" : "69",
        "SUID" : 93,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -142.81289672851562,
        "y" : 750.9277954101562
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "98",
        "Type" : "Person",
        "Position_" : "",
        "Connection_" : 5,
        "name" : "98",
        "SUID" : 92,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 438.9652404785156,
        "y" : 904.9899379784564
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "103",
        "Type" : "Person",
        "Position_" : "",
        "Connection_" : 2,
        "name" : "103",
        "SUID" : 91,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -586.1466064453125,
        "y" : -982.7604370117188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "shared_name" : "104",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 2,
        "name" : "104",
        "SUID" : 90,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -538.9561767578125,
        "y" : -815.2203979492188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "108",
        "Type" : "Person",
        "Position_" : "Honorary President",
        "Connection_" : 4,
        "name" : "108",
        "SUID" : 89,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 7.774563312530518,
        "y" : 811.13001366205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "shared_name" : "109",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 3,
        "name" : "109",
        "SUID" : 88,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -350.0871320389713,
        "y" : -320.9598737381901
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "shared_name" : "115",
        "Type" : "Person",
        "Position_" : "Honorary Secretary and Treasurer",
        "Connection_" : 4,
        "name" : "115",
        "SUID" : 87,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 164.89431762695312,
        "y" : 849.30517578125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "shared_name" : "121",
        "Type" : "Person",
        "Position_" : "Honoarary Secretary",
        "Connection_" : 4,
        "name" : "121",
        "SUID" : 86,
        "selected" : true,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -836.2313232421875,
        "y" : 398.73596626748696
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "85",
        "shared_name" : "123",
        "Type" : "Person",
        "Position_" : "Honorary Secretary",
        "Connection_" : 5,
        "name" : "123",
        "SUID" : 85,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 583.49889258795,
        "y" : 946.5216674804688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "shared_name" : "124",
        "Type" : "Person",
        "Position_" : "Honorary VP",
        "Connection_" : 4,
        "name" : "124",
        "SUID" : 84,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -261.34527587890625,
        "y" : 691.4342041015625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "shared_name" : "Parliament ",
        "Type" : "",
        "Position_" : "",
        "name" : "Parliament ",
        "SUID" : 83,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : -1772.9603271484375,
        "y" : -471.3548583984375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "shared_name" : "127",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 6,
        "name" : "127",
        "SUID" : 82,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : 693.112548828125,
        "y" : 988.7951049804688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "shared_name" : "132",
        "Type" : "Person",
        "Position_" : "Founder",
        "Connection_" : 4,
        "name" : "132",
        "SUID" : 81,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -508.7347106933594,
        "y" : 534.5674438476562
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "shared_name" : "142",
        "Type" : "Person",
        "Position_" : "Honorary Solicitor",
        "Connection_" : 4,
        "name" : "142",
        "SUID" : 80,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -290.37066650390625,
        "y" : -139.039306640625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "shared_name" : "146",
        "Type" : "Person",
        "Position_" : "Treasurer",
        "Connection_" : 3,
        "name" : "146",
        "SUID" : 79,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -397.1942705489193,
        "y" : -395.18682861328125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "shared_name" : "149",
        "Type" : "Person",
        "Position_" : "Founder",
        "Connection_" : 2,
        "name" : "149",
        "SUID" : 78,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -530.9680786132812,
        "y" : -767.3805541992188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "155",
        "Type" : "",
        "Position_" : "President",
        "name" : "155",
        "SUID" : 77,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : -287.6781005859375,
        "y" : 2.2891712188720703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "shared_name" : "East End Aid Society",
        "Type" : "",
        "Position_" : "",
        "name" : "East End Aid Society",
        "SUID" : 76,
        "selected" : false,
        "Gender_" : ""
      },
      "position" : {
        "x" : 1837.6827392578125,
        "y" : 200.50210571289062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "156",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 2,
        "name" : "156",
        "SUID" : 75,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -575.5197513340516,
        "y" : -926.9880981445312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "shared_name" : "84",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 2,
        "name" : "84",
        "SUID" : 74,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -552.5913936854795,
        "y" : -857.79345703125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "21",
        "Type" : "Person",
        "Position_" : "VP",
        "Connection_" : 3,
        "name" : "21",
        "SUID" : 73,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -666.4443271582624,
        "y" : 426.1379089355469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "shared_name" : "45",
        "Type" : "Person",
        "Position_" : "Owner",
        "Connection_" : 2,
        "name" : "45",
        "SUID" : 72,
        "selected" : false,
        "Gender_" : "Male"
      },
      "position" : {
        "x" : -517.89013671875,
        "y" : -701.7646922367858
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "207",
        "source" : "112",
        "target" : "111",
        "shared_name" : "18 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 207,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "source" : "112",
        "target" : "110",
        "shared_name" : "18 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 206,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "112",
        "target" : "109",
        "shared_name" : "18 (interacts with) Royal Commission on Alien Immigration ",
        "shared_interaction" : "interacts with",
        "name" : "18 (interacts with) Royal Commission on Alien Immigration ",
        "interaction" : "interacts with",
        "SUID" : 205,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "source" : "108",
        "target" : "107",
        "shared_name" : "23 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 204,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "source" : "108",
        "target" : "106",
        "shared_name" : "23 (interacts with) Board of Deputies of British Jews",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Board of Deputies of British Jews",
        "interaction" : "interacts with",
        "SUID" : 203,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "source" : "108",
        "target" : "105",
        "shared_name" : "23 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 202,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "source" : "108",
        "target" : "104",
        "shared_name" : "23 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "23 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 201,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "source" : "103",
        "target" : "102",
        "shared_name" : "29 (interacts with) Society of Jewish Statistics ",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Society of Jewish Statistics ",
        "interaction" : "interacts with",
        "SUID" : 200,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "source" : "103",
        "target" : "111",
        "shared_name" : "29 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 199,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "source" : "103",
        "target" : "105",
        "shared_name" : "29 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 198,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "source" : "103",
        "target" : "101",
        "shared_name" : "29 (interacts with) The Jewish Chronicle ",
        "shared_interaction" : "interacts with",
        "name" : "29 (interacts with) The Jewish Chronicle ",
        "interaction" : "interacts with",
        "SUID" : 197,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "source" : "100",
        "target" : "106",
        "shared_name" : "33 (interacts with) Board of Deputies of British Jews",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Board of Deputies of British Jews",
        "interaction" : "interacts with",
        "SUID" : 196,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "source" : "100",
        "target" : "104",
        "shared_name" : "33 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 195,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "source" : "100",
        "target" : "111",
        "shared_name" : "33 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "33 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 194,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "99",
        "target" : "104",
        "shared_name" : "42 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "42 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 193,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "source" : "99",
        "target" : "98",
        "shared_name" : "42 (interacts with) Poor Jews' Temporary Shelter",
        "shared_interaction" : "interacts with",
        "name" : "42 (interacts with) Poor Jews' Temporary Shelter",
        "interaction" : "interacts with",
        "SUID" : 192,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "source" : "99",
        "target" : "106",
        "shared_name" : "42 (interacts with) Board of Deputies of British Jews",
        "shared_interaction" : "interacts with",
        "name" : "42 (interacts with) Board of Deputies of British Jews",
        "interaction" : "interacts with",
        "SUID" : 191,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "source" : "99",
        "target" : "105",
        "shared_name" : "42 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "42 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 190,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "source" : "97",
        "target" : "111",
        "shared_name" : "44 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "44 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 189,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "source" : "97",
        "target" : "105",
        "shared_name" : "44 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "44 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 188,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "97",
        "target" : "102",
        "shared_name" : "44 (interacts with) Society of Jewish Statistics ",
        "shared_interaction" : "interacts with",
        "name" : "44 (interacts with) Society of Jewish Statistics ",
        "interaction" : "interacts with",
        "SUID" : 187,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "source" : "96",
        "target" : "101",
        "shared_name" : "47 (interacts with) The Jewish Chronicle ",
        "shared_interaction" : "interacts with",
        "name" : "47 (interacts with) The Jewish Chronicle ",
        "interaction" : "interacts with",
        "SUID" : 186,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "source" : "96",
        "target" : "110",
        "shared_name" : "47 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "47 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 185,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "source" : "96",
        "target" : "102",
        "shared_name" : "47 (interacts with) Society of Jewish Statistics ",
        "shared_interaction" : "interacts with",
        "name" : "47 (interacts with) Society of Jewish Statistics ",
        "interaction" : "interacts with",
        "SUID" : 184,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "source" : "95",
        "target" : "104",
        "shared_name" : "55 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "55 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 183,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "source" : "95",
        "target" : "94",
        "shared_name" : "55 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "55 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 182,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "source" : "95",
        "target" : "111",
        "shared_name" : "55 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "55 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 181,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "source" : "93",
        "target" : "105",
        "shared_name" : "69 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "69 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 180,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "source" : "93",
        "target" : "98",
        "shared_name" : "69 (interacts with) Poor Jews' Temporary Shelter",
        "shared_interaction" : "interacts with",
        "name" : "69 (interacts with) Poor Jews' Temporary Shelter",
        "interaction" : "interacts with",
        "SUID" : 179,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "source" : "93",
        "target" : "110",
        "shared_name" : "69 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "69 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 178,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "source" : "93",
        "target" : "109",
        "shared_name" : "69 (interacts with) Royal Commission on Alien Immigration ",
        "shared_interaction" : "interacts with",
        "name" : "69 (interacts with) Royal Commission on Alien Immigration ",
        "interaction" : "interacts with",
        "SUID" : 177,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "source" : "92",
        "target" : "105",
        "shared_name" : "98 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "98 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 176,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "source" : "92",
        "target" : "94",
        "shared_name" : "98 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "98 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 175,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "source" : "92",
        "target" : "110",
        "shared_name" : "98 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "98 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 174,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "source" : "92",
        "target" : "111",
        "shared_name" : "98 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "98 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 173,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "source" : "92",
        "target" : "107",
        "shared_name" : "98 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "98 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 172,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "source" : "91",
        "target" : "104",
        "shared_name" : "103 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "103 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 171,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "source" : "91",
        "target" : "111",
        "shared_name" : "103 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "103 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 170,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "source" : "90",
        "target" : "111",
        "shared_name" : "104 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "104 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 169,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "source" : "90",
        "target" : "104",
        "shared_name" : "104 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "104 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 168,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "source" : "89",
        "target" : "94",
        "shared_name" : "108 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "108 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 167,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "source" : "89",
        "target" : "105",
        "shared_name" : "108 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "108 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 166,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "source" : "89",
        "target" : "109",
        "shared_name" : "108 (interacts with) Royal Commission on Alien Immigration ",
        "shared_interaction" : "interacts with",
        "name" : "108 (interacts with) Royal Commission on Alien Immigration ",
        "interaction" : "interacts with",
        "SUID" : 165,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "source" : "89",
        "target" : "104",
        "shared_name" : "108 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "108 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 164,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "source" : "88",
        "target" : "110",
        "shared_name" : "109 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "109 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 163,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "source" : "88",
        "target" : "107",
        "shared_name" : "109 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "109 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 162,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "source" : "88",
        "target" : "104",
        "shared_name" : "109 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "109 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 161,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "source" : "87",
        "target" : "110",
        "shared_name" : "115 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "115 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 160,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "source" : "87",
        "target" : "105",
        "shared_name" : "115 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "115 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 159,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "source" : "87",
        "target" : "104",
        "shared_name" : "115 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "115 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 158,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "source" : "87",
        "target" : "107",
        "shared_name" : "115 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "115 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 157,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "source" : "87",
        "target" : "101",
        "shared_name" : "115 (interacts with) The Jewish Chronicle ",
        "shared_interaction" : "interacts with",
        "name" : "115 (interacts with) The Jewish Chronicle ",
        "interaction" : "interacts with",
        "SUID" : 156,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "source" : "86",
        "target" : "107",
        "shared_name" : "121 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "121 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 155,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "source" : "86",
        "target" : "105",
        "shared_name" : "121 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "121 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 154,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "source" : "86",
        "target" : "110",
        "shared_name" : "121 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "121 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 153,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "source" : "86",
        "target" : "104",
        "shared_name" : "121 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "121 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 152,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "source" : "85",
        "target" : "94",
        "shared_name" : "123 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "123 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 151,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "source" : "85",
        "target" : "104",
        "shared_name" : "123 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "123 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 150,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "source" : "85",
        "target" : "105",
        "shared_name" : "123 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "123 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 149,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "source" : "85",
        "target" : "109",
        "shared_name" : "123 (interacts with) Royal Commission on Alien Immigration ",
        "shared_interaction" : "interacts with",
        "name" : "123 (interacts with) Royal Commission on Alien Immigration ",
        "interaction" : "interacts with",
        "SUID" : 148,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "source" : "85",
        "target" : "98",
        "shared_name" : "123 (interacts with) Poor Jews' Temporary Shelter",
        "shared_interaction" : "interacts with",
        "name" : "123 (interacts with) Poor Jews' Temporary Shelter",
        "interaction" : "interacts with",
        "SUID" : 147,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "source" : "84",
        "target" : "105",
        "shared_name" : "124 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "124 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 146,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "source" : "84",
        "target" : "83",
        "shared_name" : "124 (interacts with) Parliament ",
        "shared_interaction" : "interacts with",
        "name" : "124 (interacts with) Parliament ",
        "interaction" : "interacts with",
        "SUID" : 145,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "source" : "84",
        "target" : "109",
        "shared_name" : "124 (interacts with) Royal Commission on Alien Immigration ",
        "shared_interaction" : "interacts with",
        "name" : "124 (interacts with) Royal Commission on Alien Immigration ",
        "interaction" : "interacts with",
        "SUID" : 144,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "source" : "84",
        "target" : "104",
        "shared_name" : "124 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "124 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 143,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "source" : "82",
        "target" : "105",
        "shared_name" : "127 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 142,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "source" : "82",
        "target" : "94",
        "shared_name" : "127 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 141,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "source" : "82",
        "target" : "83",
        "shared_name" : "127 (interacts with) Parliament ",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Parliament ",
        "interaction" : "interacts with",
        "SUID" : 140,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "source" : "82",
        "target" : "110",
        "shared_name" : "127 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 139,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "source" : "82",
        "target" : "111",
        "shared_name" : "127 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 138,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "source" : "82",
        "target" : "104",
        "shared_name" : "127 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "127 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 137,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "source" : "81",
        "target" : "110",
        "shared_name" : "132 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "132 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 136,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "source" : "81",
        "target" : "107",
        "shared_name" : "132 (interacts with) Jewish Religious Education Board ",
        "shared_interaction" : "interacts with",
        "name" : "132 (interacts with) Jewish Religious Education Board ",
        "interaction" : "interacts with",
        "SUID" : 135,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "source" : "81",
        "target" : "98",
        "shared_name" : "132 (interacts with) Poor Jews' Temporary Shelter",
        "shared_interaction" : "interacts with",
        "name" : "132 (interacts with) Poor Jews' Temporary Shelter",
        "interaction" : "interacts with",
        "SUID" : 134,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "source" : "81",
        "target" : "105",
        "shared_name" : "132 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "132 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 133,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "source" : "80",
        "target" : "111",
        "shared_name" : "142 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "142 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 132,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "source" : "80",
        "target" : "110",
        "shared_name" : "142 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "142 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 131,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "source" : "80",
        "target" : "106",
        "shared_name" : "142 (interacts with) Board of Deputies of British Jews",
        "shared_interaction" : "interacts with",
        "name" : "142 (interacts with) Board of Deputies of British Jews",
        "interaction" : "interacts with",
        "SUID" : 130,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "source" : "80",
        "target" : "105",
        "shared_name" : "142 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "142 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 129,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "source" : "79",
        "target" : "94",
        "shared_name" : "146 (interacts with) Anglo-Jewish Association",
        "shared_interaction" : "interacts with",
        "name" : "146 (interacts with) Anglo-Jewish Association",
        "interaction" : "interacts with",
        "SUID" : 128,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "source" : "79",
        "target" : "110",
        "shared_name" : "146 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "146 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 127,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "source" : "79",
        "target" : "104",
        "shared_name" : "146 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "146 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 126,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "source" : "78",
        "target" : "105",
        "shared_name" : "149 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "149 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 125,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "source" : "78",
        "target" : "110",
        "shared_name" : "149 (interacts with) Jewish Lads' Brigade",
        "shared_interaction" : "interacts with",
        "name" : "149 (interacts with) Jewish Lads' Brigade",
        "interaction" : "interacts with",
        "SUID" : 124,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "source" : "77",
        "target" : "104",
        "shared_name" : "155 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "155 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 123,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "source" : "77",
        "target" : "76",
        "shared_name" : "155 (interacts with) East End Aid Society",
        "shared_interaction" : "interacts with",
        "name" : "155 (interacts with) East End Aid Society",
        "interaction" : "interacts with",
        "SUID" : 122,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "source" : "75",
        "target" : "111",
        "shared_name" : "156 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "156 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 121,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "source" : "75",
        "target" : "76",
        "shared_name" : "156 (interacts with) East End Aid Society",
        "shared_interaction" : "interacts with",
        "name" : "156 (interacts with) East End Aid Society",
        "interaction" : "interacts with",
        "SUID" : 120,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "source" : "74",
        "target" : "105",
        "shared_name" : "84 (interacts with) Maccabæns",
        "shared_interaction" : "interacts with",
        "name" : "84 (interacts with) Maccabæns",
        "interaction" : "interacts with",
        "SUID" : 119,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "source" : "74",
        "target" : "76",
        "shared_name" : "84 (interacts with) East End Aid Society",
        "shared_interaction" : "interacts with",
        "name" : "84 (interacts with) East End Aid Society",
        "interaction" : "interacts with",
        "SUID" : 118,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "source" : "73",
        "target" : "106",
        "shared_name" : "21 (interacts with) Board of Deputies of British Jews",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Board of Deputies of British Jews",
        "interaction" : "interacts with",
        "SUID" : 117,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "source" : "73",
        "target" : "76",
        "shared_name" : "21 (interacts with) East End Aid Society",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) East End Aid Society",
        "interaction" : "interacts with",
        "SUID" : 116,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "source" : "73",
        "target" : "104",
        "shared_name" : "21 (interacts with) Jewish Working Men's Club ",
        "shared_interaction" : "interacts with",
        "name" : "21 (interacts with) Jewish Working Men's Club ",
        "interaction" : "interacts with",
        "SUID" : 115,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "source" : "72",
        "target" : "111",
        "shared_name" : "45 (interacts with) Jewish Board of Guardians",
        "shared_interaction" : "interacts with",
        "name" : "45 (interacts with) Jewish Board of Guardians",
        "interaction" : "interacts with",
        "SUID" : 114,
        "Committee" : "",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "source" : "72",
        "target" : "101",
        "shared_name" : "45 (interacts with) The Jewish Chronicle ",
        "shared_interaction" : "interacts with",
        "name" : "45 (interacts with) The Jewish Chronicle ",
        "interaction" : "interacts with",
        "SUID" : 113,
        "Committee" : "Executive",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}